from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Cart, CartItem
from Product.models import Product

def add_to_cart(request, product_id):
    if not request.user.is_authenticated:
        return redirect('login')

    if request.user.groups.filter(name='Buyer').exists():  # Only buyers can add to cart
        product = get_object_or_404(Product, id=product_id)
        cart, _ = Cart.objects.get_or_create(user=request.user)
        cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
        if not created:
            cart_item.quantity += 1  # Increment quantity if the item is already in the cart
        cart_item.save()
        messages.success(request, 'Item added to cart successfully.')
        return redirect('product_list')  # Redirect to product list or cart view as needed

    messages.error(request, 'You do not have permission to add items to the cart.')
    return redirect('product_list')

# Update Cart Item
def update_cart_item(request, item_id):
    if not request.user.is_authenticated:
        return redirect('login')

    if request.user.groups.filter(name='Buyer').exists():  # Only buyers can update cart items
        cart_item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
        if request.method == 'POST':
            quantity = request.POST.get('quantity')
            cart_item.quantity = quantity  # Update quantity
            cart_item.save()
            messages.success(request, 'Cart item updated successfully.')
            return redirect('cart_detail')  # Redirect to cart view

    messages.error(request, 'You do not have permission to update cart items.')
    return redirect('cart_detail')

# Remove from Cart
def remove_from_cart(request, item_id):
    if not request.user.is_authenticated:
        return redirect('login')

    if request.user.groups.filter(name='Buyer').exists():  # Only buyers can remove items
        cart_item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
        cart_item.delete()
        messages.success(request, 'Item removed from cart successfully.')
        return redirect('cart_detail')  # Redirect to cart view

    messages.error(request, 'You do not have permission to remove items from the cart.')
    return redirect('cart_detail')

@login_required
def cart_detail(request):
    cart = get_object_or_404(Cart, user=request.user)
    items = cart.items.all()
    total_amount = sum(item.quantity * item.product.price for item in items)

    return render(request, 'cart/cart_detail.html', {
        'items': items,
        'total_amount': total_amount,
    })

